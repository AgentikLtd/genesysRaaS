/**
 * Visual Rule Editor Component
 * Main component that provides visual editing capabilities for individual rules
 */

import React, { useState, useEffect, useCallback } from 'react';
import { Card, Space, Button, message, Alert, Tooltip } from 'antd';
import { EyeOutlined, EditOutlined, InfoCircleOutlined } from '@ant-design/icons';
import RuleSelector from './RuleSelector';
import RuleFlow from './RuleFlow';
import { Rule, RulesConfig } from './types';
import { produce } from 'immer';
import { validateRule } from './utils/validation';

interface VisualRuleEditorProps {
  rulesConfig: RulesConfig;
  onRuleUpdate: (updatedConfig: RulesConfig) => void;
  readOnly?: boolean;
}

/**
 * Visual Rule Editor main component
 * Provides rule selection and isolated editing functionality
 */
export const VisualRuleEditor: React.FC<VisualRuleEditorProps> = ({
  rulesConfig,
  onRuleUpdate,
  readOnly = false
}) => {
  const [selectedRuleIndex, setSelectedRuleIndex] = useState<number | null>(null);
  const [selectedRule, setSelectedRule] = useState<Rule | null>(null);
  const [isEditing, setIsEditing] = useState(false);
  const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false);

  /**
   * Update selected rule when index changes
   */
  useEffect(() => {
    if (selectedRuleIndex !== null && rulesConfig.rules[selectedRuleIndex]) {
      setSelectedRule(rulesConfig.rules[selectedRuleIndex]);
    } else {
      setSelectedRule(null);
    }
  }, [selectedRuleIndex, rulesConfig]);

  /**
   * Handle rule selection from dropdown
   */
  const handleRuleSelect = useCallback((index: number) => {
    // Warn about unsaved changes
    if (hasUnsavedChanges) {
      if (!window.confirm('You have unsaved changes. Do you want to discard them?')) {
        return;
      }
    }
    
    setSelectedRuleIndex(index);
    setIsEditing(false);
    setHasUnsavedChanges(false);
  }, [hasUnsavedChanges]);

  /**
   * Handle rule changes from visual editor
   */
  const handleRuleChange = useCallback((updatedRule: Rule) => {
    if (selectedRuleIndex === null) return;

    // Validate the updated rule
    const validation = validateRule(updatedRule);
    if (!validation.isValid) {
      message.error(`Rule validation failed: ${validation.errors[0]}`);
      return;
    }

    // Use immer to ensure immutable update
    const updatedConfig = produce(rulesConfig, draft => {
      draft.rules[selectedRuleIndex] = updatedRule;
    });

    // Update parent component
    onRuleUpdate(updatedConfig);
    setHasUnsavedChanges(false);
    message.success(`Rule "${updatedRule.name}" updated successfully`);
  }, [selectedRuleIndex, rulesConfig, onRuleUpdate]);

  /**
   * Handle unsaved changes notification
   */
  const handleUnsavedChanges = useCallback((hasChanges: boolean) => {
    setHasUnsavedChanges(hasChanges);
  }, []);

  /**
   * Toggle edit mode
   */
  const toggleEditMode = useCallback(() => {
    if (isEditing && hasUnsavedChanges) {
      if (!window.confirm('You have unsaved changes. Do you want to discard them?')) {
        return;
      }
    }
    setIsEditing(!isEditing);
    if (isEditing) {
      setHasUnsavedChanges(false);
    }
  }, [isEditing, hasUnsavedChanges]);

  return (
    <Space direction="vertical" style={{ width: '100%' }} size="large">
      {/* Header with rule selector and mode toggle */}
      <Card>
        <Space style={{ width: '100%', justifyContent: 'space-between' }}>
          <Space>
            <RuleSelector
              rules={rulesConfig.rules}
              selectedIndex={selectedRuleIndex}
              onSelect={handleRuleSelect}
            />
            <Tooltip title="Select a rule from the dropdown to view or edit it">
              <InfoCircleOutlined style={{ color: '#1890ff' }} />
            </Tooltip>
          </Space>
          
          {selectedRule && !readOnly && (
            <Button
              icon={isEditing ? <EyeOutlined /> : <EditOutlined />}
              onClick={toggleEditMode}
              type={isEditing ? 'default' : 'primary'}
            >
              {isEditing ? 'View Mode' : 'Edit Mode'}
            </Button>
          )}
        </Space>
      </Card>

      {/* Info alert for new users */}
      {!selectedRule && (
        <Alert
          message="Getting Started"
          description="Select a rule from the dropdown above to view its visual representation. You can then switch to Edit Mode to make changes."
          type="info"
          showIcon
          closable
        />
      )}

      {/* Visual rule editor */}
      {selectedRule && (
        <RuleFlow
          rule={selectedRule}
          isEditing={isEditing && !readOnly}
          onChange={handleRuleChange}
          onUnsavedChanges={handleUnsavedChanges}
        />
      )}

      {/* Unsaved changes warning */}
      {hasUnsavedChanges && (
        <Alert
          message="Unsaved Changes"
          description="You have unsaved changes. Click 'Save Changes' in the editor to apply them."
          type="warning"
          showIcon
          style={{ position: 'fixed', bottom: 20, right: 20, zIndex: 1000 }}
        />
      )}
    </Space>
  );
};

export default VisualRuleEditor;