/**
 * Logical Operator Node Component
 * Visual representation of AND/OR/NOT operators
 */

import React from 'react';
import { Handle, Position, NodeProps } from 'reactflow';
import { Card, Tag } from 'antd';
import { 
  MergeCellsOutlined, 
  BranchesOutlined, 
  StopOutlined 
} from '@ant-design/icons';

/**
 * Node component for logical operators (AND/OR/NOT)
 */
const LogicalOperatorNode: React.FC<NodeProps> = ({ data, selected }) => {
  const operatorConfig = {
    all: {
      label: 'AND',
      color: '#52c41a',
      icon: <MergeCellsOutlined />,
      description: 'All conditions must be true'
    },
    any: {
      label: 'OR',
      color: '#1890ff',
      icon: <BranchesOutlined />,
      description: 'Any condition must be true'
    },
    not: {
      label: 'NOT',
      color: '#ff4d4f',
      icon: <StopOutlined />,
      description: 'Condition must be false'
    }
  };

  const config = operatorConfig[data.type as keyof typeof operatorConfig];

  return (
    <Card
      size="small"
      style={{
        minWidth: 140,
        border: selected ? '2px solid #1890ff' : '1px solid #d9d9d9',
        borderRadius: '8px',
        background: selected ? '#f0f9ff' : '#fff',
        cursor: 'pointer'
      }}
      bodyStyle={{ 
        padding: '12px 16px',
        textAlign: 'center'
      }}
      hoverable
    >
      <Handle 
        type="target" 
        position={Position.Top}
        style={{
          background: '#666',
          width: 8,
          height: 8
        }}
      />
      
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8 }}>
        {config.icon}
        <Tag 
          color={config.color} 
          style={{ 
            fontSize: '16px', 
            padding: '4px 12px',
            margin: 0,
            fontWeight: 'bold'
          }}
        >
          {config.label}
        </Tag>
      </div>
      
      <div style={{ 
        fontSize: '11px', 
        color: '#666', 
        marginTop: '4px' 
      }}>
        {config.description}
      </div>
      
      <Handle 
        type="source" 
        position={Position.Bottom}
        style={{
          background: config.color,
          width: 8,
          height: 8
        }}
      />
    </Card>
  );
};

export default LogicalOperatorNode;