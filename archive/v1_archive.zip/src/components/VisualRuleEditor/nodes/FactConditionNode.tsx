
/**
 * Fact Condition Node Component
 * Visual representation of a condition check
 */

import React from 'react';
import { Handle, Position, NodeProps } from 'reactflow';
import { Card, Tag, Space, Typography, Tooltip } from 'antd';
import { 
  FieldStringOutlined,
  NumberOutlined,
  CalendarOutlined,
  OrderedListOutlined
} from '@ant-design/icons';

const { Text } = Typography;

/**
 * Get icon for value type
 */
const getValueIcon = (value: any) => {
  if (Array.isArray(value)) return <OrderedListOutlined />;
  if (typeof value === 'number') return <NumberOutlined />;
  if (typeof value === 'string' && /^\d{4}-\d{2}-\d{2}/.test(value)) return <CalendarOutlined />;
  return <FieldStringOutlined />;
};

/**
 * Format display value
 */
const formatValue = (value: any): string => {
  if (value === null) return 'null';
  if (value === undefined) return 'undefined';
  if (Array.isArray(value)) return `[${value.join(', ')}]`;
  if (typeof value === 'object') return JSON.stringify(value);
  if (typeof value === 'string' && value.length > 20) {
    return value.substring(0, 20) + '...';
  }
  return String(value);
};

/**
 * Get operator display label
 */
const getOperatorLabel = (operator: string): string => {
  const operatorLabels: Record<string, string> = {
    equal: '=',
    notEqual: '≠',
    greaterThan: '>',
    greaterThanInclusive: '≥',
    lessThan: '<',
    lessThanInclusive: '≤',
    in: 'IN',
    notIn: 'NOT IN',
    contains: 'CONTAINS',
    doesNotContain: 'NOT CONTAINS',
    containsAny: 'CONTAINS ANY',
    matchesPattern: 'MATCHES',
    startsWith: 'STARTS WITH',
    endsWith: 'ENDS WITH'
  };
  return operatorLabels[operator] || operator;
};

/**
 * Node component for fact conditions
 */
const FactConditionNode: React.FC<NodeProps> = ({ data, selected }) => {
  const isInputValue = data.fact === 'inputValue';
  const displayKey = isInputValue && data.params?.key ? data.params.key : data.fact;
  
  return (
    <Card
      size="small"
      style={{
        minWidth: 260,
        maxWidth: 320,
        border: selected ? '2px solid #1890ff' : '1px solid #d9d9d9',
        borderRadius: '8px',
        background: selected ? '#f0f9ff' : '#fff',
        cursor: 'pointer'
      }}
      bodyStyle={{ padding: '12px' }}
      hoverable
    >
      <Handle 
        type="target" 
        position={Position.Top}
        style={{
          background: '#666',
          width: 8,
          height: 8
        }}
      />
      
      <Space direction="vertical" style={{ width: '100%' }} size="small">
        {/* Fact/Key */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <Text type="secondary" style={{ fontSize: '12px', minWidth: 50 }}>
            {isInputValue ? 'Key:' : 'Fact:'}
          </Text>
          <Tag color="blue" style={{ margin: 0 }}>
            {displayKey}
          </Tag>
        </div>

        {/* Operator */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <Text type="secondary" style={{ fontSize: '12px', minWidth: 50 }}>
            Operator:
          </Text>
          <Tag color="orange" style={{ margin: 0, fontFamily: 'monospace' }}>
            {getOperatorLabel(data.operator)}
          </Tag>
        </div>

        {/* Value */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <Text type="secondary" style={{ fontSize: '12px', minWidth: 50 }}>
            Value:
          </Text>
          <Tooltip title={JSON.stringify(data.value, null, 2)}>
            <Tag 
              icon={getValueIcon(data.value)} 
              style={{ 
                margin: 0,
                maxWidth: '180px',
                overflow: 'hidden',
                textOverflow: 'ellipsis'
              }}
            >
              {formatValue(data.value)}
            </Tag>
          </Tooltip>
        </div>

        {/* Additional params */}
        {data.params && Object.keys(data.params).length > 1 && (
          <div style={{ 
            fontSize: '11px', 
            color: '#666',
            borderTop: '1px solid #f0f0f0',
            paddingTop: '4px',
            marginTop: '4px'
          }}>
            <Text type="secondary">
              +{Object.keys(data.params).length - 1} more param(s)
            </Text>
          </div>
        )}
      </Space>
      
      <Handle 
        type="source" 
        position={Position.Bottom}
        style={{
          background: '#52c41a',
          width: 8,
          height: 8
        }}
      />
    </Card>
  );
};

export default FactConditionNode;