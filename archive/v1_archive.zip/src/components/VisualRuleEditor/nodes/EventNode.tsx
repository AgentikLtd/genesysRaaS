
/**
 * Event Node Component
 * Visual representation of the rule's action/destination
 */

import React from 'react';
import { Handle, Position, NodeProps } from 'reactflow';
import { Card, Tag, Space, Typography } from 'antd';
import { 
  SendOutlined, 
  RiseOutlined,
  FallOutlined,
  MinusOutlined,
  InfoCircleOutlined
} from '@ant-design/icons';

const { Text } = Typography;

/**
 * Get priority icon and color
 */
const getPriorityConfig = (priority?: string) => {
  switch (priority) {
    case 'high':
      return { icon: <RiseOutlined />, color: 'red' };
    case 'medium':
      return { icon: <MinusOutlined />, color: 'orange' };
    case 'low':
      return { icon: <FallOutlined />, color: 'blue' };
    default:
      return { icon: null, color: 'default' };
  }
};

/**
 * Node component for rule events/actions
 */
const EventNode: React.FC<NodeProps> = ({ data, selected }) => {
  const priorityConfig = getPriorityConfig(data.priority);
  
  return (
    <Card
      size="small"
      style={{
        minWidth: 280,
        border: selected ? '2px solid #52c41a' : '2px solid #52c41a',
        borderRadius: '8px',
        background: selected ? '#f6ffed' : '#f6ffed',
        cursor: 'pointer'
      }}
      bodyStyle={{ padding: '16px' }}
      hoverable
    >
      <Handle 
        type="target" 
        position={Position.Top}
        style={{
          background: '#52c41a',
          width: 10,
          height: 10
        }}
      />
      
      <Space direction="vertical" style={{ width: '100%' }} size="middle">
        {/* Header */}
        <div style={{ textAlign: 'center' }}>
          <Space>
            <SendOutlined style={{ fontSize: '20px', color: '#52c41a' }} />
            <Text strong style={{ fontSize: '16px' }}>Route Destination</Text>
          </Space>
        </div>

        {/* Destination */}
        <div style={{ 
          background: '#fff', 
          padding: '8px 12px', 
          borderRadius: '6px',
          border: '1px solid #d9f7be'
        }}>
          <Space direction="vertical" style={{ width: '100%' }} size="small">
            <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <Text type="secondary" style={{ fontSize: '12px' }}>
                Queue/Flow:
              </Text>
              <Tag color="green" style={{ margin: 0, fontSize: '14px' }}>
                {data.destination}
              </Tag>
            </div>

            {/* Priority */}
            {data.priority && (
              <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                <Text type="secondary" style={{ fontSize: '12px' }}>
                  Priority:
                </Text>
                <Tag 
                  icon={priorityConfig.icon} 
                  color={priorityConfig.color}
                  style={{ margin: 0 }}
                >
                  {data.priority.toUpperCase()}
                </Tag>
              </div>
            )}

            {/* Reason */}
            {data.reason && (
              <div style={{ 
                borderTop: '1px solid #f0f0f0', 
                paddingTop: '8px',
                marginTop: '4px'
              }}>
                <Space size="small">
                  <InfoCircleOutlined style={{ color: '#666' }} />
                  <Text type="secondary" style={{ fontSize: '12px' }}>
                    {data.reason}
                  </Text>
                </Space>
              </div>
            )}
          </Space>
        </div>
      </Space>
    </Card>
  );
};

export default EventNode;