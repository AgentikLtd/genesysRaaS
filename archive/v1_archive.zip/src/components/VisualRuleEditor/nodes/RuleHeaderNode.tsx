
/**
 * Rule Header Node Component
 * Visual representation of the rule metadata
 */

import React from 'react';
import { Handle, Position, NodeProps } from 'reactflow';
import { Card, Tag, Space, Typography, Badge } from 'antd';
import { 
  CrownOutlined,
  FileTextOutlined,
  ThunderboltOutlined
} from '@ant-design/icons';

const { Text, Title } = Typography;

/**
 * Get priority level and color
 */
const getPriorityLevel = (priority: number): { label: string; color: string } => {
  if (priority >= 90) return { label: 'Critical', color: 'red' };
  if (priority >= 70) return { label: 'High', color: 'orange' };
  if (priority >= 50) return { label: 'Medium', color: 'blue' };
  if (priority >= 30) return { label: 'Low', color: 'cyan' };
  return { label: 'Minimal', color: 'default' };
};

/**
 * Node component for rule header/metadata
 */
const RuleHeaderNode: React.FC<NodeProps> = ({ data, selected }) => {
  const priorityLevel = getPriorityLevel(data.priority);
  
  return (
    <Card
      size="small"
      style={{
        minWidth: 320,
        border: selected ? '2px solid #722ed1' : '2px solid #722ed1',
        borderRadius: '8px',
        background: selected ? '#f9f0ff' : '#f9f0ff',
        cursor: 'pointer'
      }}
      bodyStyle={{ padding: '16px' }}
      hoverable
    >
      <Space direction="vertical" style={{ width: '100%' }} size="middle">
        {/* Rule Name */}
        <div style={{ textAlign: 'center' }}>
          <Space align="center">
            <CrownOutlined style={{ fontSize: '24px', color: '#722ed1' }} />
            <Title level={4} style={{ margin: 0, color: '#722ed1' }}>
              {data.name}
            </Title>
          </Space>
        </div>

        {/* Priority Badge */}
        <div style={{ textAlign: 'center' }}>
          <Space>
            <ThunderboltOutlined />
            <Text type="secondary">Priority:</Text>
            <Badge 
              count={data.priority} 
              style={{ 
                backgroundColor: priorityLevel.color,
                fontSize: '16px',
                padding: '0 8px'
              }} 
            />
            <Tag color={priorityLevel.color} style={{ margin: 0 }}>
              {priorityLevel.label}
            </Tag>
          </Space>
        </div>

        {/* Description */}
        {data.description && (
          <div style={{ 
            background: '#fff', 
            padding: '8px 12px', 
            borderRadius: '6px',
            border: '1px solid #e1d5f0'
          }}>
            <Space size="small">
              <FileTextOutlined style={{ color: '#722ed1' }} />
              <Text type="secondary" style={{ fontSize: '13px' }}>
                {data.description}
              </Text>
            </Space>
          </div>
        )}

        {/* Info text */}
        <div style={{ 
          textAlign: 'center', 
          fontSize: '11px', 
          color: '#666',
          borderTop: '1px solid #e1d5f0',
          paddingTop: '8px'
        }}>
          Rule will be evaluated when conditions below are met
        </div>
      </Space>
      
      <Handle 
        type="source" 
        position={Position.Bottom}
        style={{
          background: '#722ed1',
          width: 10,
          height: 10
        }}
      />
    </Card>
  );
};

export default RuleHeaderNode;