/**
 * Rule Selector Component
 * Dropdown for selecting individual rules to edit
 */

import React from 'react';
import { Select, Tag, Space, Typography } from 'antd';
import { Rule } from './types';

const { Text } = Typography;
const { Option } = Select;

interface RuleSelectorProps {
  rules: Rule[];
  selectedIndex: number | null;
  onSelect: (index: number) => void;
}

/**
 * Dropdown component for rule selection
 * Shows rule name, priority, and description
 */
const RuleSelector: React.FC<RuleSelectorProps> = ({
  rules,
  selectedIndex,
  onSelect
}) => {
  /**
   * Get priority color based on value
   */
  const getPriorityColor = (priority: number): string => {
    if (priority >= 90) return 'red';
    if (priority >= 70) return 'orange';
    if (priority >= 50) return 'blue';
    return 'default';
  };

  /**
   * Format rule option label
   */
  const formatRuleLabel = (rule: Rule, index: number): string => {
    return `${index + 1}. ${rule.name}`;
  };

  return (
    <Select
      style={{ minWidth: 400 }}
      placeholder="Select a rule to view or edit"
      value={selectedIndex}
      onChange={onSelect}
      showSearch
      allowClear={false}
      filterOption={(input, option) => {
        const rule = rules[option?.value as number];
        if (!rule) return false;
        
        const searchText = input.toLowerCase();
        return (
          rule.name.toLowerCase().includes(searchText) ||
          (rule.description?.toLowerCase().includes(searchText) ?? false)
        );
      }}
    >
      {rules.map((rule, index) => (
        <Option key={index} value={index}>
          <Space direction="vertical" style={{ width: '100%' }}>
            <Space>
              <Text strong>{formatRuleLabel(rule, index)}</Text>
              <Tag color={getPriorityColor(rule.priority)}>
                Priority: {rule.priority}
              </Tag>
            </Space>
            {rule.description && (
              <Text type="secondary" style={{ fontSize: '12px' }}>
                {rule.description}
              </Text>
            )}
          </Space>
        </Option>
      ))}
    </Select>
  );
};

export default RuleSelector;