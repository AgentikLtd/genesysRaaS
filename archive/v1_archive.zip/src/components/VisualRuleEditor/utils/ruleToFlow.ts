
/**
 * Utility to convert a rule object into React Flow nodes and edges
 * Handles nested conditions and creates appropriate visual representation
 */

import { Node, Edge, Position } from 'reactflow';
import { Rule, RuleCondition, CustomNode } from '../types';

let nodeIdCounter = 0;

/**
 * Generate unique node ID
 */
const generateNodeId = (): string => {
  return `node-${Date.now()}-${nodeIdCounter++}`;
};

/**
 * Calculate node positions for better layout
 */
const calculatePosition = (level: number, index: number, total: number): { x: number; y: number } => {
  const baseY = level * 180;
  const baseX = 400;
  const spacing = 280;
  
  if (total === 1) {
    return { x: baseX, y: baseY };
  }
  
  const offset = (index - (total - 1) / 2) * spacing;
  return { x: baseX + offset, y: baseY };
};

/**
 * Convert a rule object to React Flow nodes and edges
 */
export const ruleToFlow = (rule: Rule): { nodes: Node[]; edges: Edge[] } => {
  const nodes: Node[] = [];
  const edges: Edge[] = [];
  nodeIdCounter = 0;

  // Create rule header node
  const headerNodeId = 'rule-header';
  const headerNode: Node = {
    id: headerNodeId,
    type: 'ruleHeader',
    position: { x: 400, y: 0 },
    data: {
      name: rule.name,
      priority: rule.priority,
      description: rule.description
    },
    draggable: false
  };
  nodes.push(headerNode);

  /**
   * Recursively process conditions and create nodes
   */
  const processCondition = (
    condition: RuleCondition,
    parentId: string | null = null,
    level: number = 1,
    index: number = 0,
    total: number = 1
  ): string => {
    const nodeId = generateNodeId();
    const position = calculatePosition(level, index, total);

    if (condition.all || condition.any || condition.not) {
      // Create logical operator node
      const type = condition.all ? 'all' : condition.any ? 'any' : 'not';
      const logicalNode: Node = {
        id: nodeId,
        type: 'logicalOperator',
        position,
        data: { 
          type,
          parentId 
        }
      };
      nodes.push(logicalNode);

      // Connect to parent if exists
      if (parentId) {
        edges.push({
          id: `${parentId}-${nodeId}`,
          source: parentId,
          target: nodeId,
          type: 'smoothstep',
          animated: false,
          style: { strokeWidth: 2 }
        });
      }

      // Process child conditions
      let childConditions: RuleCondition[] = [];
      if (condition.all) {
        childConditions = condition.all;
      } else if (condition.any) {
        childConditions = condition.any;
      } else if (condition.not) {
        childConditions = [condition.not];
      }

      // Process each child condition
      childConditions.forEach((childCondition, childIndex) => {
        processCondition(
          childCondition, 
          nodeId, 
          level + 1, 
          childIndex, 
          childConditions.length
        );
      });
    } else if (condition.fact || condition.condition) {
      // Create fact condition node
      const factNode: Node = {
        id: nodeId,
        type: 'factCondition',
        position,
        data: {
          fact: condition.fact || 'condition',
          operator: condition.operator || 'reference',
          value: condition.value || condition.condition,
          params: condition.params,
          parentId
        }
      };
      nodes.push(factNode);

      // Connect to parent if exists
      if (parentId) {
        edges.push({
          id: `${parentId}-${nodeId}`,
          source: parentId,
          target: nodeId,
          type: 'smoothstep',
          animated: false,
          style: { strokeWidth: 2 }
        });
      }
    }

    return nodeId;
  };

  // Process the main condition
  let mainConditionId: string | null = null;
  if (rule.conditions) {
    mainConditionId = processCondition(rule.conditions, headerNodeId);
  }

  // Create event node
  const eventNodeId = 'event-node';
  const eventPosition = calculatePosition(
    Math.max(3, nodes.length > 10 ? 4 : 3), 
    0, 
    1
  );
  
  const eventNode: Node = {
    id: eventNodeId,
    type: 'eventNode',
    position: eventPosition,
    data: {
      destination: rule.event.params.destination,
      priority: rule.event.params.priority,
      reason: rule.event.params.reason
    },
    draggable: false
  };
  nodes.push(eventNode);

  // Connect last condition to event
  const lastConditionNode = mainConditionId || headerNodeId;
  edges.push({
    id: `${lastConditionNode}-${eventNodeId}`,
    source: lastConditionNode,
    target: eventNodeId,
    type: 'smoothstep',
    animated: true,
    style: { 
      strokeWidth: 2,
      stroke: '#52c41a'
    }
  });

  return { nodes, edges };
};

/**
 * Auto-layout nodes for better visualization
 */
export const autoLayoutNodes = (nodes: Node[], edges: Edge[]): Node[] => {
  // Build adjacency list
  const children = new Map<string, string[]>();
  edges.forEach(edge => {
    if (!children.has(edge.source)) {
      children.set(edge.source, []);
    }
    children.get(edge.source)!.push(edge.target);
  });

  // Perform layout
  const layoutNode = (nodeId: string, level: number = 0, index: number = 0, siblings: number = 1): void => {
    const node = nodes.find(n => n.id === nodeId);
    if (!node) return;

    const position = calculatePosition(level, index, siblings);
    node.position = position;

    const nodeChildren = children.get(nodeId) || [];
    nodeChildren.forEach((childId, childIndex) => {
      layoutNode(childId, level + 1, childIndex, nodeChildren.length);
    });
  };

  // Start layout from header
  layoutNode('rule-header');

  return nodes;
};