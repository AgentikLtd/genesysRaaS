/**
 * Rule Flow Component
 * React Flow canvas for visual rule editing
 */

import React, { useState, useCallback, useEffect } from 'react';
import ReactFlow, {
  Node,
  Edge,
  Controls,
  MiniMap,
  Background,
  useNodesState,
  useEdgesState,
  Connection,
  BackgroundVariant,
  NodeTypes,
  MarkerType,
  Panel
} from 'reactflow';
import { Card, Button, Space, message, Modal, Badge } from 'antd';
import { 
  SaveOutlined, 
  RedoOutlined, 
  ZoomInOutlined,
  ZoomOutOutlined,
  FullscreenOutlined
} from '@ant-design/icons';
import 'reactflow/dist/style.css';

import { Rule } from './types';
import { ruleToFlow, autoLayoutNodes } from './utils/ruleToFlow';
import { flowToRule, validateFlowStructure } from './utils/flowToRule';
import { validateFlow, getValidationSummary } from './utils/validation';
import LogicalOperatorNode from './nodes/LogicalOperatorNode';
import FactConditionNode from './nodes/FactConditionNode';
import EventNode from './nodes/EventNode';
import RuleHeaderNode from './nodes/RuleHeaderNode';
import PropertiesPanel from './panels/PropertiesPanel';
import ValidationPanel from './panels/ValidationPanel';

// Define custom node types
const nodeTypes: NodeTypes = {
  logicalOperator: LogicalOperatorNode,
  factCondition: FactConditionNode,
  eventNode: EventNode,
  ruleHeader: RuleHeaderNode
};

interface RuleFlowProps {
  rule: Rule;
  isEditing: boolean;
  onChange: (rule: Rule) => void;
  onUnsavedChanges?: (hasChanges: boolean) => void;
}

/**
 * Visual rule editor using React Flow
 */
const RuleFlow: React.FC<RuleFlowProps> = ({ 
  rule, 
  isEditing, 
  onChange,
  onUnsavedChanges 
}) => {
  const [nodes, setNodes, onNodesChange] = useNodesState([]);
  const [edges, setEdges, onEdgesChange] = useEdgesState([]);
  const [selectedNode, setSelectedNode] = useState<Node | null>(null);
  const [hasChanges, setHasChanges] = useState(false);
  const [validationResult, setValidationResult] = useState<any>(null);
  const [showValidation, setShowValidation] = useState(false);

  /**
   * Initialize flow from rule
   */
  useEffect(() => {
    const { nodes: flowNodes, edges: flowEdges } = ruleToFlow(rule);
    const layoutNodes = autoLayoutNodes(flowNodes, flowEdges);
    setNodes(layoutNodes);
    setEdges(flowEdges);
    setHasChanges(false);
    setSelectedNode(null);
    
    // Validate initial state
    const validation = validateFlow(layoutNodes, flowEdges);
    setValidationResult(validation);
  }, [rule, setNodes, setEdges]);

  /**
   * Track changes
   */
  useEffect(() => {
    if (onUnsavedChanges) {
      onUnsavedChanges(hasChanges);
    }
  }, [hasChanges, onUnsavedChanges]);

  /**
   * Handle node selection
   */
  const onNodeClick = useCallback((event: React.MouseEvent, node: Node) => {
    if (isEditing) {
      setSelectedNode(node);
    }
  }, [isEditing]);

  /**
   * Handle node updates from properties panel
   */
  const handleNodeUpdate = useCallback((nodeId: string, newData: any) => {
    setNodes((nds) =>
      nds.map((node) => {
        if (node.id === nodeId) {
          return { ...node, data: newData };
        }
        return node;
      })
    );
    setHasChanges(true);
    
    // Re-validate after changes
    setTimeout(() => {
      const validation = validateFlow(nodes, edges);
      setValidationResult(validation);
    }, 100);
  }, [nodes, edges, setNodes]);

  /**
   * Handle saving changes
   */
  const handleSave = useCallback(() => {
    try {
      // Validate flow structure
      const structureErrors = validateFlowStructure(nodes, edges);
      if (structureErrors.length > 0) {
        message.error(`Cannot save: ${structureErrors[0]}`);
        return;
      }

      // Validate flow logic
      const validation = validateFlow(nodes, edges);
      if (!validation.isValid) {
        Modal.confirm({
          title: 'Validation Errors',
          content: `There are validation errors:\n${validation.errors.join('\n')}\n\nDo you want to save anyway?`,
          onOk: () => {
            saveRule();
          }
        });
        return;
      }

      saveRule();
    } catch (error: any) {
      message.error(`Failed to save rule: ${error.message}`);
    }
  }, [nodes, edges, rule, onChange]);

  /**
   * Save the rule
   */
  const saveRule = useCallback(() => {
    try {
      const updatedRule = flowToRule(nodes, edges, rule);
      onChange(updatedRule);
      setHasChanges(false);
      message.success('Rule saved successfully');
    } catch (error: any) {
      message.error(`Failed to save rule: ${error.message}`);
    }
  }, [nodes, edges, rule, onChange]);

  /**
   * Reset to original rule
   */
  const handleReset = useCallback(() => {
    Modal.confirm({
      title: 'Reset Changes',
      content: 'Are you sure you want to discard all changes?',
      onOk: () => {
        const { nodes: flowNodes, edges: flowEdges } = ruleToFlow(rule);
        const layoutNodes = autoLayoutNodes(flowNodes, flowEdges);
        setNodes(layoutNodes);
        setEdges(flowEdges);
        setHasChanges(false);
        setSelectedNode(null);
        message.info('Reset to original rule');
      }
    });
  }, [rule, setNodes, setEdges]);

  /**
   * Auto-layout nodes
   */
  const handleAutoLayout = useCallback(() => {
    const layoutNodes = autoLayoutNodes(nodes, edges);
    setNodes(layoutNodes);
  }, [nodes, edges, setNodes]);

  /**
   * Handle edge deletion in edit mode
   */
  const onEdgesDelete = useCallback((deletedEdges: Edge[]) => {
    if (isEditing) {
      setHasChanges(true);
    }
  }, [isEditing]);

  /**
   * Custom edge style
   */
  const defaultEdgeOptions = {
    style: { strokeWidth: 2 },
    markerEnd: {
      type: MarkerType.ArrowClosed,
      width: 20,
      height: 20
    }
  };

  return (
    <Card
      title={
        <Space>
          <span>Visual Editor: {rule.name}</span>
          <Badge 
            count={hasChanges ? 'Modified' : null} 
            style={{ backgroundColor: '#ff4d4f' }}
          />
        </Space>
      }
      extra={
        isEditing && (
          <Space>
            <Button
              onClick={() => setShowValidation(!showValidation)}
              type={validationResult && !validationResult.isValid ? 'danger' : 'default'}
            >
              Validation {validationResult && `(${getValidationSummary(validationResult)})`}
            </Button>
            <Button
              icon={<FullscreenOutlined />}
              onClick={handleAutoLayout}
              title="Auto Layout"
            />
            <Button
              icon={<RedoOutlined />}
              onClick={handleReset}
              disabled={!hasChanges}
            >
              Reset
            </Button>
            <Button
              type="primary"
              icon={<SaveOutlined />}
              onClick={handleSave}
              disabled={!hasChanges}
            >
              Save Changes
            </Button>
          </Space>
        )
      }
      bodyStyle={{ padding: 0 }}
    >
      <div style={{ height: '600px', width: '100%', position: 'relative' }}>
        <ReactFlow
          nodes={nodes}
          edges={edges}
          onNodesChange={isEditing ? onNodesChange : undefined}
          onEdgesChange={isEditing ? onEdgesChange : undefined}
          onEdgesDelete={onEdgesDelete}
          onNodeClick={onNodeClick}
          nodeTypes={nodeTypes}
          defaultEdgeOptions={defaultEdgeOptions}
          fitView
          attributionPosition="bottom-right"
          nodesDraggable={isEditing}
          nodesConnectable={false}
          elementsSelectable={isEditing}
          deleteKeyCode={isEditing ? 'Delete' : null}
        >
          <Controls 
            showInteractive={false}
            position="top-left"
          />
          <MiniMap 
            nodeStrokeColor={(node) => {
              if (node.type === 'ruleHeader') return '#722ed1';
              if (node.type === 'eventNode') return '#52c41a';
              if (node.type === 'logicalOperator') return '#1890ff';
              return '#666';
            }}
            nodeColor={(node) => {
              if (node.type === 'ruleHeader') return '#f9f0ff';
              if (node.type === 'eventNode') return '#f6ffed';
              if (node.type === 'logicalOperator') return '#e6f7ff';
              return '#fafafa';
            }}
            pannable
            zoomable
          />
          <Background variant={BackgroundVariant.Dots} gap={12} size={1} />
          
          {/* Custom panels */}
          <Panel position="top-right">
            <div style={{ 
              background: 'white', 
              padding: '8px 12px', 
              borderRadius: '4px',
              boxShadow: '0 2px 4px rgba(0,0,0,0.1)'
            }}>
              <Space size="small">
                <span>Mode:</span>
                <strong>{isEditing ? 'Edit' : 'View'}</strong>
              </Space>
            </div>
          </Panel>
        </ReactFlow>
        
        {/* Properties panel for selected node */}
        {isEditing && selectedNode && (
          <PropertiesPanel
            node={selectedNode}
            onUpdate={handleNodeUpdate}
            onClose={() => setSelectedNode(null)}
          />
        )}
        
        {/* Validation panel */}
        {showValidation && validationResult && (
          <ValidationPanel
            result={validationResult}
            onClose={() => setShowValidation(false)}
          />
        )}
      </div>
    </Card>
  );
};

export default RuleFlow;