import React, { useState, useEffect } from 'react';
import { Outlet, useNavigate, useLocation } from 'react-router-dom';
import { 
  Layout, 
  Menu, 
  Avatar, 
  Dropdown, 
  Space, 
  Badge, 
  Button,
  Tooltip,
  Typography,
  MenuProps
} from 'antd';
import {
  EditOutlined,
  HistoryOutlined,
  FileTextOutlined,
  UserOutlined,
  LogoutOutlined,
  QuestionCircleOutlined,
  SafetyOutlined
} from '@ant-design/icons';
import { useAuth } from '../contexts/AuthContext';
import { HelpWiki } from './HelpWiki';
import dayjs from 'dayjs';

const { Header, Sider, Content } = Layout;
const { Title } = Typography;

export const MainLayout: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { user, logout, tokenExpiry } = useAuth();
  const [helpVisible, setHelpVisible] = useState(false);
  const [tokenStatus, setTokenStatus] = useState({ status: 'success', text: 'Valid' });

  // Update token status indicator
  useEffect(() => {
    const updateTokenStatus = () => {
      if (!tokenExpiry) {
        setTokenStatus({ status: 'error', text: 'No token' });
        return;
      }

      const now = new Date();
      const timeLeft = tokenExpiry.getTime() - now.getTime();
      const minutesLeft = Math.floor(timeLeft / 60000);

      if (minutesLeft <= 0) {
        setTokenStatus({ status: 'error', text: 'Expired' });
      } else if (minutesLeft <= 5) {
        setTokenStatus({ status: 'warning', text: `Expires in ${minutesLeft}m` });
      } else {
        setTokenStatus({ status: 'success', text: `Valid for ${minutesLeft}m` });
      }
    };

    updateTokenStatus();
    const interval = setInterval(updateTokenStatus, 30000); // Update every 30 seconds

    return () => clearInterval(interval);
  }, [tokenExpiry]);

  const menuItems: MenuProps['items'] = [
    {
      key: '/rules',
      icon: <EditOutlined />,
      label: 'Rules Editor',
    },
    {
      key: '/logs',
      icon: <FileTextOutlined />,
      label: 'Execution Logs',
    },
    {
      key: '/history',
      icon: <HistoryOutlined />,
      label: 'Version History',
    },
  ];

  const userMenuItems: MenuProps['items'] = [
    {
      key: 'profile',
      icon: <UserOutlined />,
      label: user?.email || 'User',
      disabled: true,
    },
    {
      type: 'divider',
    },
    {
      key: 'logout',
      icon: <LogoutOutlined />,
      label: 'Logout',
      danger: true,
      onClick: logout,
    },
  ];

  return (
    <>
      <Layout style={{ minHeight: '100vh' }}>
        <Header style={{ 
          background: '#001529', 
          padding: '0 24px',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between'
        }}>
          <div style={{ color: 'white', fontSize: '18px', fontWeight: 'bold' }}>
            Genesys Rules Engine Manager
          </div>
          
          <Space size="middle">
            {/* Token Status Indicator */}
            <Tooltip title={`OAuth Token Status`}>
              <Badge 
                status={tokenStatus.status as any}
                text={
                  <span style={{ color: 'white', fontSize: '12px' }}>
                    <SafetyOutlined /> {tokenStatus.text}
                  </span>
                }
              />
            </Tooltip>

            {/* Help Button */}
            <Button
              type="text"
              icon={<QuestionCircleOutlined />}
              onClick={() => setHelpVisible(true)}
              style={{ color: 'white' }}
            >
              Help
            </Button>

            {/* User Menu */}
            <Dropdown menu={{ items: userMenuItems }} placement="bottomRight">
              <Space style={{ cursor: 'pointer', color: 'white' }}>
                <Avatar icon={<UserOutlined />} />
                <span>{user?.name || 'User'}</span>
              </Space>
            </Dropdown>
          </Space>
        </Header>
        
        <Layout>
          <Sider width={240} theme="light">
            <Menu
              mode="inline"
              selectedKeys={[location.pathname]}
              items={menuItems}
              onClick={({ key }) => navigate(key)}
              style={{ height: '100%', borderRight: 0 }}
            />
            
            {/* Version info in footer of sider */}
            <div style={{ 
              position: 'absolute', 
              bottom: 0, 
              width: '100%', 
              padding: '16px',
              borderTop: '1px solid #f0f0f0',
              background: '#fafafa'
            }}>
              <div style={{ fontSize: '12px', colour: '#999' }}>
                <div>Rules Engine v2.0</div>
                <div>© 2024 Your Company</div>
              </div>
            </div>
          </Sider>
          
          <Layout style={{ padding: '24px' }}>
            <Content style={{ 
              background: '#fff', 
              padding: 24, 
              margin: 0, 
              minHeight: 280,
              borderRadius: '8px',
              boxShadow: '0 1px 2px rgba(0,0,0,0.1)'
            }}>
              <Outlet />
            </Content>
          </Layout>
        </Layout>
      </Layout>

      {/* Help Wiki Modal */}
      <HelpWiki visible={helpVisible} onClose={() => setHelpVisible(false)} />
    </>
  );
};