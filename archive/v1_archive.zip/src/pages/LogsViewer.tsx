import React, { useState, useEffect } from 'react';
import {
  Card,
  Table,
  Button,
  Space,
  Tag,
  DatePicker,
  Select,
  Statistic,
  Row,
  Col,
  Modal,
  Descriptions,
  Input,
  message,
  Empty,
  Tooltip
} from 'antd';
import {
  ReloadOutlined,
  SearchOutlined,
  BarChartOutlined,
  ClockCircleOutlined,
  CheckCircleOutlined,
  CloseCircleOutlined,
  InfoCircleOutlined
} from '@ant-design/icons';
import { ColumnType } from 'antd/es/table';
import dayjs from 'dayjs';
import { genesysService } from '../services/genesysService';
import { Line, Pie } from 'recharts';
import {
  LineChart,
  PieChart,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip as RechartsTooltip,
  Legend,
  ResponsiveContainer,
  Cell
} from 'recharts';

const { RangePicker } = DatePicker;
const { Option } = Select;

interface LogEntry {
  key: string;
  timestamp: string;
  input: any;
  output: string;
  rulesVersion: number;
  executionTime: number;
  matchedRules: string;
  matchedRulesList: string[];
  error: string;
  traceId: string;
}

export const LogsViewer: React.FC = () => {
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [total, setTotal] = useState(0);
  const [pageNumber, setPageNumber] = useState(1);
  const [pageSize, setPageSize] = useState(50);
  const [selectedLog, setSelectedLog] = useState<LogEntry | null>(null);
  const [detailModalVisible, setDetailModalVisible] = useState(false);
  const [statsModalVisible, setStatsModalVisible] = useState(false);
  const [stats, setStats] = useState<any>(null);
  
  // Filters
  const [dateRange, setDateRange] = useState<[dayjs.Dayjs, dayjs.Dayjs] | null>(null);
  const [errorFilter, setErrorFilter] = useState<'all' | 'errors' | 'success'>('all');
  const [searchText, setSearchText] = useState('');

  useEffect(() => {
    loadLogs();
  }, [pageNumber, pageSize, dateRange, errorFilter]);

  const loadLogs = async () => {
    try {
      setLoading(true);
      
      const filters: any = {};
      
      if (dateRange) {
        filters.startDate = dateRange[0].toISOString();
        filters.endDate = dateRange[1].toISOString();
      }
      
      if (errorFilter === 'errors') {
        filters.hasError = true;
      } else if (errorFilter === 'success') {
        filters.hasError = false;
      }
      
      const response = await genesysService.getExecutionLogs({
        pageNumber,
        pageSize,
        ...filters
      });
      
      setLogs(response.results || []);
      setTotal(response.total || 0);
      
      // Calculate stats
      calculateStats(response.results || []);
    } catch (error) {
      message.error('Failed to load execution logs');
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const calculateStats = (logData: LogEntry[]) => {
    const totalLogs = logData.length;
    const errorLogs = logData.filter(log => log.error).length;
    const avgExecutionTime = logData.reduce((sum, log) => sum + log.executionTime, 0) / totalLogs || 0;
    
    // Destination distribution
    const destinationCounts: Record<string, number> = {};
    logData.forEach(log => {
      destinationCounts[log.output] = (destinationCounts[log.output] || 0) + 1;
    });
    
    const destinationData = Object.entries(destinationCounts)
      .map(([name, value]) => ({ name, value }))
      .sort((a, b) => b.value - a.value)
      .slice(0, 5);
    
    // Time series data (last 24 hours)
    const timeSeriesData: Record<string, number> = {};
    logData.forEach(log => {
      const hour = dayjs(log.timestamp).format('HH:00');
      timeSeriesData[hour] = (timeSeriesData[hour] || 0) + 1;
    });
    
    const timeData = Object.entries(timeSeriesData)
      .map(([time, count]) => ({ time, count }))
      .sort((a, b) => a.time.localeCompare(b.time));
    
    setStats({
      totalLogs,
      errorLogs,
      successRate: ((totalLogs - errorLogs) / totalLogs * 100).toFixed(1),
      avgExecutionTime: avgExecutionTime.toFixed(2),
      destinationData,
      timeData
    });
  };

  const columns: ColumnType<LogEntry>[] = [
    {
      title: 'Timestamp',
      dataIndex: 'timestamp',
      key: 'timestamp',
      width: 180,
      render: (timestamp: string) => dayjs(timestamp).format('YYYY-MM-DD HH:mm:ss'),
      sorter: true
    },
    {
      title: 'Destination',
      dataIndex: 'output',
      key: 'output',
      render: (output: string) => <Tag color="blue">{output}</Tag>
    },
    {
      title: 'Rules Version',
      dataIndex: 'rulesVersion',
      key: 'rulesVersion',
      width: 120,
      render: (version: number) => `v${version}`
    },
    {
      title: 'Execution Time',
      dataIndex: 'executionTime',
      key: 'executionTime',
      width: 140,
      render: (time: number) => (
        <Tag color={time > 100 ? 'red' : 'green'}>
          <ClockCircleOutlined /> {time}ms
        </Tag>
      ),
      sorter: true
    },
    {
      title: 'Status',
      dataIndex: 'error',
      key: 'status',
      width: 100,
      render: (error: string) => error ? (
        <Tag color="error" icon={<CloseCircleOutlined />}>Error</Tag>
      ) : (
        <Tag color="success" icon={<CheckCircleOutlined />}>Success</Tag>
      ),
      filters: [
        { text: 'Success', value: 'success' },
        { text: 'Error', value: 'error' }
      ]
    },
    {
      title: 'Actions',
      key: 'actions',
      width: 100,
      render: (_, record) => (
        <Button
          size="small"
          icon={<InfoCircleOutlined />}
          onClick={() => {
            setSelectedLog(record);
            setDetailModalVisible(true);
          }}
        >
          Details
        </Button>
      )
    }
  ];

  const filteredLogs = logs.filter(log => {
    if (!searchText) return true;
    
    const searchLower = searchText.toLowerCase();
    return (
      log.output.toLowerCase().includes(searchLower) ||
      JSON.stringify(log.input).toLowerCase().includes(searchLower) ||
      log.matchedRules.toLowerCase().includes(searchLower)
    );
  });

  const renderStats = () => {
    if (!stats) return null;
    
    const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884d8'];
    
    return (
      <div>
        {/* Summary Stats */}
        <Row gutter={16} style={{ marginBottom: 24 }}>
          <Col span={6}>
            <Statistic title="Total Executions" value={stats.totalLogs} />
          </Col>
          <Col span={6}>
            <Statistic title="Success Rate" value={stats.successRate} suffix="%" />
          </Col>
          <Col span={6}>
            <Statistic title="Avg Execution Time" value={stats.avgExecutionTime} suffix="ms" />
          </Col>
          <Col span={6}>
            <Statistic 
              title="Errors" 
              value={stats.errorLogs} 
              valueStyle={{ color: stats.errorLogs > 0 ? '#ff4d4f' : '#3f8600' }}
            />
          </Col>
        </Row>
        
        {/* Charts */}
        <Row gutter={16}>
          <Col span={12}>
            <Card title="Destination Distribution" size="small">
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={stats.destinationData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {stats.destinationData.map((entry: any, index: number) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <RechartsTooltip />
                </PieChart>
              </ResponsiveContainer>
            </Card>
          </Col>
          <Col span={12}>
            <Card title="Executions Over Time" size="small">
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={stats.timeData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="time" />
                  <YAxis />
                  <RechartsTooltip />
                  <Legend />
                  <Line type="monotone" dataKey="count" stroke="#8884d8" name="Executions" />
                </LineChart>
              </ResponsiveContainer>
            </Card>
          </Col>
        </Row>
      </div>
    );
  };

  return (
    <>
      <Card
        title="Execution Logs"
        extra={
          <Space>
            <Button
              icon={<BarChartOutlined />}
              onClick={() => setStatsModalVisible(true)}
            >
              Statistics
            </Button>
            <Button
              icon={<ReloadOutlined />}
              onClick={loadLogs}
              loading={loading}
            >
              Refresh
            </Button>
          </Space>
        }
      >
        {/* Filters */}
        <Space style={{ marginBottom: 16 }} wrap>
          <RangePicker
            value={dateRange}
            onChange={(dates) => setDateRange(dates as any)}
            showTime
            format="YYYY-MM-DD HH:mm"
          />
          <Select
            style={{ width: 120 }}
            value={errorFilter}
            onChange={setErrorFilter}
          >
            <Option value="all">All Status</Option>
            <Option value="success">Success Only</Option>
            <Option value="errors">Errors Only</Option>
          </Select>
          <Input
            placeholder="Search logs..."
            prefix={<SearchOutlined />}
            value={searchText}
            onChange={(e) => setSearchText(e.target.value)}
            style={{ width: 200 }}
          />
        </Space>
        
        {/* Table */}
        <Table
          columns={columns}
          dataSource={filteredLogs}
          loading={loading}
          rowKey="key"
          pagination={{
            current: pageNumber,
            pageSize: pageSize,
            total: total,
            showSizeChanger: true,
            showTotal: (total) => `Total ${total} logs`,
            onChange: (page, size) => {
              setPageNumber(page);
              setPageSize(size || 50);
            }
          }}
          locale={{
            emptyText: <Empty description="No execution logs found" />
          }}
        />
      </Card>

      {/* Detail Modal */}
      <Modal
        title="Log Details"
        open={detailModalVisible}
        onCancel={() => setDetailModalVisible(false)}
        footer={null}
        width={800}
      >
        {selectedLog && (
          <Descriptions bordered column={1}>
            <Descriptions.Item label="Timestamp">
              {dayjs(selectedLog.timestamp).format('YYYY-MM-DD HH:mm:ss.SSS')}
            </Descriptions.Item>
            <Descriptions.Item label="Trace ID">
              <code>{selectedLog.traceId || 'N/A'}</code>
            </Descriptions.Item>
            <Descriptions.Item label="Rules Version">
              v{selectedLog.rulesVersion}
            </Descriptions.Item>
            <Descriptions.Item label="Execution Time">
              <Tag color={selectedLog.executionTime > 100 ? 'red' : 'green'}>
                {selectedLog.executionTime}ms
              </Tag>
            </Descriptions.Item>
            <Descriptions.Item label="Output Destination">
              <Tag color="blue">{selectedLog.output}</Tag>
            </Descriptions.Item>
            <Descriptions.Item label="Matched Rules">
              {selectedLog.matchedRulesList.length > 0 ? (
                <Space wrap>
                  {selectedLog.matchedRulesList.map((rule, index) => (
                    <Tag key={index} color="green">{rule}</Tag>
                  ))}
                </Space>
              ) : (
                <span style={{ colour: '#999' }}>No rules matched</span>
              )}
            </Descriptions.Item>
            <Descriptions.Item label="Input">
              <pre style={{ margin: 0, fontSize: '12px' }}>
                {JSON.stringify(selectedLog.input, null, 2)}
              </pre>
            </Descriptions.Item>
            {selectedLog.error && (
              <Descriptions.Item label="Error">
                <Tag color="error">{selectedLog.error}</Tag>
              </Descriptions.Item>
            )}
          </Descriptions>
        )}
      </Modal>

      {/* Statistics Modal */}
      <Modal
        title="Execution Statistics"
        open={statsModalVisible}
        onCancel={() => setStatsModalVisible(false)}
        footer={null}
        width={1000}
      >
        {renderStats()}
      </Modal>
    </>
  );
};

export default LogsViewer;