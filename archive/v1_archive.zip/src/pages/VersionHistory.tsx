import React, { useState, useEffect } from 'react';
import { Table, Card, Button, Space, Tag, Modal, Typography, message, Tooltip } from 'antd';
import { RollbackOutlined, EyeOutlined, DiffOutlined } from '@ant-design/icons';
import type { ColumnsType } from 'antd/es/table';
import dayjs from 'dayjs';
import Editor from '@monaco-editor/react';

const { Title, Text } = Typography;

interface RuleVersion {
  id: string;
  version: string;
  deployedBy: string;
  deployedAt: string;
  description: string;
  rules: any;
  isActive: boolean;
}

const VersionHistory: React.FC = () => {
  const [versions, setVersions] = useState<RuleVersion[]>([]);
  const [loading, setLoading] = useState(false);
  const [viewModalVisible, setViewModalVisible] = useState(false);
  const [selectedVersion, setSelectedVersion] = useState<RuleVersion | null>(null);
  const [rollbackModalVisible, setRollbackModalVisible] = useState(false);

  useEffect(() => {
    loadVersions();
  }, []);

  const loadVersions = async () => {
    setLoading(true);
    // Simulate API call
    setTimeout(() => {
      const mockVersions: RuleVersion[] = Array.from({ length: 10 }, (_, i) => ({
        id: `v${Date.now() - i * 86400000}`,
        version: `v${10 - i}`,
        deployedBy: ['user@example.com', 'admin@example.com'][Math.floor(Math.random() * 2)],
        deployedAt: dayjs().subtract(i, 'day').toISOString(),
        description: `${i === 0 ? 'Current version' : `Historical version ${10 - i}`} - Updated routing rules`,
        rules: {
          defaultDestination: 'Default_Queue',
          rules: [
            {
              name: `rule_${10 - i}`,
              priority: 100,
              conditions: { all: [] },
              event: { type: 'route', params: { destination: `Queue_${10 - i}` } }
            }
          ]
        },
        isActive: i === 0
      }));
      setVersions(mockVersions);
      setLoading(false);
    }, 1000);
  };

  const handleView = (version: RuleVersion) => {
    setSelectedVersion(version);
    setViewModalVisible(true);
  };

  const handleRollback = (version: RuleVersion) => {
    setSelectedVersion(version);
    setRollbackModalVisible(true);
  };

  const confirmRollback = async () => {
    if (!selectedVersion) return;
    
    setLoading(true);
    try {
      // TODO: Implement actual rollback
      await new Promise(resolve => setTimeout(resolve, 1500));
      message.success(`Successfully rolled back to ${selectedVersion.version}`);
      setRollbackModalVisible(false);
      loadVersions();
    } catch (error) {
      message.error('Failed to rollback version');
    } finally {
      setLoading(false);
    }
  };

  const columns: ColumnsType<RuleVersion> = [
    {
      title: 'Version',
      dataIndex: 'version',
      key: 'version',
      render: (text, record) => (
        <Space>
          <Text strong>{text}</Text>
          {record.isActive && <Tag color="green">ACTIVE</Tag>}
        </Space>
      )
    },
    {
      title: 'Deployed By',
      dataIndex: 'deployedBy',
      key: 'deployedBy'
    },
    {
      title: 'Deployed At',
      dataIndex: 'deployedAt',
      key: 'deployedAt',
      render: (text) => dayjs(text).format('YYYY-MM-DD HH:mm:ss'),
      sorter: (a, b) => dayjs(a.deployedAt).unix() - dayjs(b.deployedAt).unix(),
      defaultSortOrder: 'descend'
    },
    {
      title: 'Description',
      dataIndex: 'description',
      key: 'description',
      ellipsis: true
    },
    {
      title: 'Actions',
      key: 'actions',
      render: (_, record) => (
        <Space>
          <Tooltip title="View rules">
            <Button 
              icon={<EyeOutlined />} 
              onClick={() => handleView(record)}
              size="small"
            />
          </Tooltip>
          {!record.isActive && (
            <Tooltip title="Rollback to this version">
              <Button 
                icon={<RollbackOutlined />} 
                onClick={() => handleRollback(record)}
                size="small"
                danger
              />
            </Tooltip>
          )}
        </Space>
      )
    }
  ];

  return (
    <>
      <Card
        title="Version History"
        extra={
          <Button onClick={loadVersions} loading={loading}>
            Refresh
          </Button>
        }
      >
        <Table
          columns={columns}
          dataSource={versions}
          rowKey="id"
          loading={loading}
          pagination={{
            pageSize: 10,
            showSizeChanger: true
          }}
        />
      </Card>

      {/* View Modal */}
      <Modal
        title={`View Rules - ${selectedVersion?.version}`}
        open={viewModalVisible}
        onCancel={() => setViewModalVisible(false)}
        footer={[
          <Button key="close" onClick={() => setViewModalVisible(false)}>
            Close
          </Button>
        ]}
        width={800}
      >
        {selectedVersion && (
          <Space direction="vertical" style={{ width: '100%' }} size="large">
            <div>
              <Text type="secondary">Deployed by: </Text>
              <Text>{selectedVersion.deployedBy}</Text>
              <br />
              <Text type="secondary">Deployed at: </Text>
              <Text>{dayjs(selectedVersion.deployedAt).format('YYYY-MM-DD HH:mm:ss')}</Text>
              <br />
              <Text type="secondary">Description: </Text>
              <Text>{selectedVersion.description}</Text>
            </div>
            
            <Editor
              height="400px"
              defaultLanguage="json"
              value={JSON.stringify(selectedVersion.rules, null, 2)}
              options={{
                readOnly: true,
                minimap: { enabled: false },
                scrollBeyondLastLine: false
              }}
              theme="vs-dark"
            />
          </Space>
        )}
      </Modal>

      {/* Rollback Modal */}
      <Modal
        title="Confirm Rollback"
        open={rollbackModalVisible}
        onOk={confirmRollback}
        onCancel={() => setRollbackModalVisible(false)}
        confirmLoading={loading}
        okText="Rollback"
        okButtonProps={{ danger: true }}
      >
        <Space direction="vertical">
          <Text>
            Are you sure you want to rollback to <Text strong>{selectedVersion?.version}</Text>?
          </Text>
          <Text type="warning">
            This will replace the current active rules with the rules from this version.
          </Text>
        </Space>
      </Modal>
    </>
  );
};

export default VersionHistory;