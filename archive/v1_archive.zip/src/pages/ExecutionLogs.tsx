import React, { useState, useEffect } from 'react';
import { Table, Card, DatePicker, Select, Space, Tag, Button, Statistic, Row, Col } from 'antd';
import { ReloadOutlined, DownloadOutlined } from '@ant-design/icons';
import type { ColumnsType } from 'antd/es/table';
import dayjs from 'dayjs';

const { RangePicker } = DatePicker;
const { Option } = Select;

interface LogEntry {
  id: string;
  timestamp: string;
  input: any;
  output: string;
  matchedRules: string[];
  executionTime: number;
  status: 'success' | 'error' | 'default';
  errorMessage?: string;
}

const ExecutionLogs: React.FC = () => {
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [loading, setLoading] = useState(false);
  const [filters, setFilters] = useState({
    dateRange: [dayjs().subtract(24, 'hour'), dayjs()] as [dayjs.Dayjs, dayjs.Dayjs],
    status: 'all'
  });

  // Generate mock data for demonstration
  useEffect(() => {
    loadLogs();
  }, [filters]);

  const loadLogs = async () => {
    setLoading(true);
    // Simulate API call
    setTimeout(() => {
      const mockLogs: LogEntry[] = Array.from({ length: 50 }, (_, i) => ({
        id: `log-${i}`,
        timestamp: dayjs().subtract(Math.random() * 24, 'hour').toISOString(),
        input: {
          brand: ['Admiral', 'esure', 'Sheilas Wheels'][Math.floor(Math.random() * 3)],
          intent: ['sales', 'service', 'cancel'][Math.floor(Math.random() * 3)],
          customerType: ['new', 'existing'][Math.floor(Math.random() * 2)]
        },
        output: `Queue_${Math.floor(Math.random() * 10)}`,
        matchedRules: [`rule_${Math.floor(Math.random() * 5)}`],
        executionTime: Math.floor(Math.random() * 100) + 10,
        status: Math.random() > 0.9 ? 'error' : 'success'
      }));
      setLogs(mockLogs);
      setLoading(false);
    }, 1000);
  };

  const columns: ColumnsType<LogEntry> = [
    {
      title: 'Timestamp',
      dataIndex: 'timestamp',
      key: 'timestamp',
      render: (text) => dayjs(text).format('YYYY-MM-DD HH:mm:ss'),
      sorter: (a, b) => dayjs(a.timestamp).unix() - dayjs(b.timestamp).unix(),
      defaultSortOrder: 'descend'
    },
    {
      title: 'Input',
      dataIndex: 'input',
      key: 'input',
      render: (input) => (
        <Space direction="vertical" size="small">
          {Object.entries(input).map(([key, value]) => (
            <Tag key={key}>{`${key}: ${value}`}</Tag>
          ))}
        </Space>
      )
    },
    {
      title: 'Output',
      dataIndex: 'output',
      key: 'output',
      render: (text) => <Tag color="blue">{text}</Tag>
    },
    {
      title: 'Matched Rules',
      dataIndex: 'matchedRules',
      key: 'matchedRules',
      render: (rules) => rules.join(', ')
    },
    {
      title: 'Execution Time',
      dataIndex: 'executionTime',
      key: 'executionTime',
      render: (time) => `${time}ms`,
      sorter: (a, b) => a.executionTime - b.executionTime
    },
    {
      title: 'Status',
      dataIndex: 'status',
      key: 'status',
      render: (status) => (
        <Tag color={status === 'success' ? 'green' : 'red'}>
          {status.toUpperCase()}
        </Tag>
      ),
      filters: [
        { text: 'Success', value: 'success' },
        { text: 'Error', value: 'error' }
      ],
      onFilter: (value, record) => record.status === value
    }
  ];

  const handleExport = () => {
    // TODO: Implement CSV export
    console.log('Exporting logs...');
  };

  const stats = {
    total: logs.length,
    success: logs.filter(l => l.status === 'success').length,
    error: logs.filter(l => l.status === 'error').length,
    avgExecutionTime: logs.reduce((acc, log) => acc + log.executionTime, 0) / logs.length || 0
  };

  return (
    <Space direction="vertical" size="large" style={{ width: '100%' }}>
      {/* Statistics */}
      <Row gutter={16}>
        <Col span={6}>
          <Card>
            <Statistic title="Total Executions" value={stats.total} />
          </Card>
        </Col>
        <Col span={6}>
          <Card>
            <Statistic 
              title="Success Rate" 
              value={(stats.success / stats.total * 100).toFixed(1)} 
              suffix="%" 
              valueStyle={{ color: '#3f8600' }}
            />
          </Card>
        </Col>
        <Col span={6}>
          <Card>
            <Statistic 
              title="Errors" 
              value={stats.error} 
              valueStyle={{ color: stats.error > 0 ? '#cf1322' : undefined }}
            />
          </Card>
        </Col>
        <Col span={6}>
          <Card>
            <Statistic 
              title="Avg Execution Time" 
              value={stats.avgExecutionTime.toFixed(0)} 
              suffix="ms" 
            />
          </Card>
        </Col>
      </Row>

      {/* Filters */}
      <Card>
        <Space>
          <RangePicker
            showTime
            value={filters.dateRange}
            onChange={(dates) => dates && setFilters({ ...filters, dateRange: dates as [dayjs.Dayjs, dayjs.Dayjs] })}
          />
          <Select
            style={{ width: 120 }}
            value={filters.status}
            onChange={(value) => setFilters({ ...filters, status: value })}
          >
            <Option value="all">All Status</Option>
            <Option value="success">Success</Option>
            <Option value="error">Error</Option>
          </Select>
          <Button 
            icon={<ReloadOutlined />} 
            onClick={loadLogs}
            loading={loading}
          >
            Refresh
          </Button>
          <Button 
            icon={<DownloadOutlined />} 
            onClick={handleExport}
          >
            Export CSV
          </Button>
        </Space>
      </Card>

      {/* Logs Table */}
      <Card>
        <Table
          columns={columns}
          dataSource={logs}
          rowKey="id"
          loading={loading}
          pagination={{
            pageSize: 20,
            showSizeChanger: true,
            showTotal: (total) => `Total ${total} logs`
          }}
        />
      </Card>
    </Space>
  );
};

export default ExecutionLogs;