import React from 'react';
import { Modal, Tabs, Typography, Space, Tag, Alert, Collapse } from 'antd';
import { InfoCircleOutlined, CodeOutlined, BugOutlined, QuestionCircleOutlined } from '@ant-design/icons';

const { Title, Paragraph, Text } = Typography;
const { TabPane } = Tabs;
const { Panel } = Collapse;

interface HelpWikiProps {
  visible: boolean;
  onClose: () => void;
}

export const HelpWiki: React.FC<HelpWikiProps> = ({ visible, onClose }) => {
  return (
    <Modal
      title="Rules Engine Help"
      open={visible}
      onCancel={onClose}
      footer={null}
      width={800}
    >
      <Tabs defaultActiveKey="1">
        <TabPane tab="Getting Started" key="1" icon={<InfoCircleOutlined />}>
          <Space direction="vertical" style={{ width: '100%' }}>
            <Title level={4}>Welcome to Genesys Rules Engine Manager</Title>
            <Paragraph>
              This application allows you to manage routing rules dynamically without redeploying your Lambda function.
            </Paragraph>
            
            <Title level={5}>Key Features</Title>
            <ul>
              <li>Visual JSON editor with syntax highlighting</li>
              <li>Real-time validation</li>
              <li>Test rules before deployment</li>
              <li>Version history and rollback</li>
              <li>Execution logs and analytics</li>
            </ul>
            
            <Alert
              message="Important"
              description="Changes deployed here will immediately affect live call routing. Always test your rules before deployment."
              type="warning"
              showIcon
            />
          </Space>
        </TabPane>
        
        <TabPane tab="Rules Syntax" key="2" icon={<CodeOutlined />}>
          <Space direction="vertical" style={{ width: '100%' }}>
            <Title level={4}>Rules Engine Syntax</Title>
            
            <Collapse defaultActiveKey={['1']}>
              <Panel header="Basic Rule Structure" key="1">
                <pre>{`{
  "name": "ruleName",
  "priority": 100,
  "conditions": {
    "all": [
      {
        "fact": "inputValue",
        "params": { "key": "brand" },
        "operator": "equal",
        "value": "Admiral"
      }
    ]
  },
  "event": {
    "type": "route_determined",
    "params": {
      "destination": "Target_Queue"
    }
  }
}`}</pre>
              </Panel>
              
              <Panel header="Available Operators" key="2">
                <Space direction="vertical">
                  <Tag color="blue">equal</Tag>
                  <Tag color="blue">notEqual</Tag>
                  <Tag color="blue">in</Tag>
                  <Tag color="blue">notIn</Tag>
                  <Tag color="blue">contains</Tag>
                  <Tag color="blue">greaterThan</Tag>
                  <Tag color="blue">lessThan</Tag>
                  <Tag color="blue">greaterThanInclusive</Tag>
                  <Tag color="blue">lessThanInclusive</Tag>
                </Space>
              </Panel>
              
              <Panel header="Condition Types" key="3">
                <Space direction="vertical">
                  <div>
                    <Text strong>all:</Text> All conditions must be true (AND)
                  </div>
                  <div>
                    <Text strong>any:</Text> At least one condition must be true (OR)
                  </div>
                  <div>
                    <Text strong>not:</Text> Inverts the condition group
                  </div>
                </Space>
              </Panel>
            </Collapse>
          </Space>
        </TabPane>
        
        <TabPane tab="Troubleshooting" key="3" icon={<BugOutlined />}>
          <Space direction="vertical" style={{ width: '100%' }}>
            <Title level={4}>Common Issues</Title>
            
            <Title level={5}>1. Rules Not Matching</Title>
            <ul>
              <li>Check key names are exact (case-sensitive)</li>
              <li>Verify data types match</li>
              <li>Review rule priorities</li>
              <li>Enable logging to see evaluation details</li>
            </ul>
            
            <Title level={5}>2. Invalid JSON Error</Title>
            <ul>
              <li>Use the editor's syntax highlighting</li>
              <li>Check for missing commas</li>
              <li>Ensure all strings are quoted</li>
              <li>Validate brackets match</li>
            </ul>
            
            <Title level={5}>3. Performance Issues</Title>
            <ul>
              <li>Limit number of rules (recommended: &lt;100)</li>
              <li>Use specific conditions over broad ones</li>
              <li>Place most common rules first (higher priority)</li>
            </ul>
          </Space>
        </TabPane>
      </Tabs>
    </Modal>
  );
};

// Also export as default for compatibility
export default HelpWiki;