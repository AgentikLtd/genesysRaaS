/**
 * Template Selector Component
 * Allows users to create new rules from pre-built templates
 */

import React, { useState, useMemo } from 'react';
import {
  Modal,
  Card,
  Space,
  Typography,
  Input,
  Select,
  Form,
  Button,
  List,
  Tag,
  Divider,
  Empty,
  InputNumber,
  Switch,
  Tabs,
  Badge,
  message
} from 'antd';
import {
  FileAddOutlined,
  SearchOutlined,
  ThunderboltOutlined,
  ClockCircleOutlined,
  UserOutlined,
  GlobalOutlined,
  BranchesOutlined,
  AppstoreOutlined
} from '@ant-design/icons';
import {
  RULE_TEMPLATES,
  RuleTemplate,
  TemplateVariable,
  applyTemplate,
  getTemplateCategories,
  searchTemplates
} from '../templates/ruleTemplates';
import { Rule } from '../types';

const { Title, Text, Paragraph } = Typography;
const { Search } = Input;
const { Option } = Select;

interface TemplateSelectorProps {
  visible: boolean;
  onClose: () => void;
  onCreateRule: (rule: Rule) => void;
  existingRuleNames?: string[];
}

const categoryIcons: Record<string, React.ReactNode> = {
  'Basic': <AppstoreOutlined />,
  'Customer Type': <UserOutlined />,
  'Intent': <ThunderboltOutlined />,
  'Time-Based': <ClockCircleOutlined />,
  'Complex': <BranchesOutlined />,
  'Language': <GlobalOutlined />
};

/**
 * Template Selector Modal for creating new rules
 */
const TemplateSelector: React.FC<TemplateSelectorProps> = ({
  visible,
  onClose,
  onCreateRule,
  existingRuleNames = []
}) => {
  const [selectedTemplate, setSelectedTemplate] = useState<RuleTemplate | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [variableValues, setVariableValues] = useState<Record<string, any>>({});
  const [ruleName, setRuleName] = useState('');
  const [form] = Form.useForm();

  const categories = useMemo(() => ['all', ...getTemplateCategories()], []);

  /**
   * Filter templates based on search and category
   */
  const filteredTemplates = useMemo(() => {
    let templates = searchQuery
      ? searchTemplates(searchQuery)
      : RULE_TEMPLATES;

    if (selectedCategory !== 'all') {
      templates = templates.filter(t => t.category === selectedCategory);
    }

    return templates;
  }, [searchQuery, selectedCategory]);

  /**
   * Handle template selection
   */
  const handleTemplateSelect = (template: RuleTemplate) => {
    setSelectedTemplate(template);
    
    // Initialize variable values with defaults
    const defaultValues: Record<string, any> = {};
    template.variables?.forEach(variable => {
      defaultValues[variable.key] = variable.defaultValue || '';
    });
    setVariableValues(defaultValues);
    
    // Generate unique rule name
    const baseName = template.rule.name || 'newRule';
    let uniqueName = baseName;
    let counter = 1;
    while (existingRuleNames.includes(uniqueName)) {
      uniqueName = `${baseName}_${counter}`;
      counter++;
    }
    setRuleName(uniqueName);
    form.setFieldsValue({ ruleName: uniqueName, ...defaultValues });
  };

  /**
   * Handle rule creation
   */
  const handleCreateRule = () => {
    form.validateFields()
      .then(values => {
        if (!selectedTemplate) return;

        // Apply template with variables
        const rule = applyTemplate(selectedTemplate, {
          ...variableValues,
          ...values
        });
        
        // Set the rule name
        rule.name = values.ruleName;
        
        // Create the rule
        onCreateRule(rule);
        message.success(`Rule "${rule.name}" created from template`);
        
        // Reset and close
        handleClose();
      })
      .catch(error => {
        console.error('Validation failed:', error);
      });
  };

  /**
   * Handle modal close
   */
  const handleClose = () => {
    setSelectedTemplate(null);
    setSearchQuery('');
    setSelectedCategory('all');
    setVariableValues({});
    setRuleName('');
    form.resetFields();
    onClose();
  };

  /**
   * Render variable input based on type
   */
  const renderVariableInput = (variable: TemplateVariable) => {
    const { key, type, options } = variable;

    switch (type) {
      case 'select':
        return (
          <Select
            placeholder={`Select ${variable.label}`}
            onChange={value => setVariableValues(prev => ({ ...prev, [key]: value }))}
          >
            {options?.map(opt => (
              <Option key={opt.value} value={opt.value}>
                {opt.label}
              </Option>
            ))}
          </Select>
        );
      
      case 'number':
        return (
          <InputNumber
            placeholder={`Enter ${variable.label}`}
            style={{ width: '100%' }}
            onChange={value => setVariableValues(prev => ({ ...prev, [key]: value }))}
          />
        );
      
      case 'boolean':
        return (
          <Switch
            onChange={checked => setVariableValues(prev => ({ ...prev, [key]: checked }))}
          />
        );
      
      case 'array':
        return (
          <Select
            mode="tags"
            placeholder={`Enter ${variable.label} (press Enter to add)`}
            onChange={value => setVariableValues(prev => ({ ...prev, [key]: value }))}
          />
        );
      
      default:
        return (
          <Input
            placeholder={`Enter ${variable.label}`}
            onChange={e => setVariableValues(prev => ({ ...prev, [key]: e.target.value }))}
          />
        );
    }
  };

  return (
    <Modal
      title={
        <Space>
          <FileAddOutlined />
          <span>Create Rule from Template</span>
        </Space>
      }
      open={visible}
      onCancel={handleClose}
      width={900}
      footer={
        selectedTemplate ? [
          <Button key="back" onClick={() => setSelectedTemplate(null)}>
            Back to Templates
          </Button>,
          <Button key="cancel" onClick={handleClose}>
            Cancel
          </Button>,
          <Button key="create" type="primary" onClick={handleCreateRule}>
            Create Rule
          </Button>
        ] : [
          <Button key="cancel" onClick={handleClose}>
            Cancel
          </Button>
        ]
      }
    >
      {!selectedTemplate ? (
        <Space direction="vertical" style={{ width: '100%' }} size="large">
          {/* Search and Filter */}
          <Space style={{ width: '100%' }}>
            <Search
              placeholder="Search templates..."
              allowClear
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              style={{ width: 300 }}
              prefix={<SearchOutlined />}
            />
            <Select
              value={selectedCategory}
              onChange={setSelectedCategory}
              style={{ width: 200 }}
            >
              <Option value="all">All Categories</Option>
              {categories.slice(1).map(category => (
                <Option key={category} value={category}>
                  <Space>
                    {categoryIcons[category]}
                    {category}
                  </Space>
                </Option>
              ))}
            </Select>
          </Space>

          {/* Template List */}
          <div style={{ maxHeight: 400, overflowY: 'auto' }}>
            {filteredTemplates.length > 0 ? (
              <List
                grid={{ gutter: 16, xs: 1, sm: 1, md: 2, lg: 2 }}
                dataSource={filteredTemplates}
                renderItem={template => (
                  <List.Item>
                    <Card
                      hoverable
                      onClick={() => handleTemplateSelect(template)}
                      style={{ cursor: 'pointer' }}
                    >
                      <Space direction="vertical" style={{ width: '100%' }}>
                        <Space>
                          {categoryIcons[template.category]}
                          <Text strong>{template.name}</Text>
                        </Space>
                        <Paragraph
                          ellipsis={{ rows: 2 }}
                          style={{ marginBottom: 8, color: '#666' }}
                        >
                          {template.description}
                        </Paragraph>
                        <Space>
                          <Tag color="blue">{template.category}</Tag>
                          {template.variables && (
                            <Tag color="green">
                              {template.variables.length} variable{template.variables.length !== 1 ? 's' : ''}
                            </Tag>
                          )}
                        </Space>
                      </Space>
                    </Card>
                  </List.Item>
                )}
              />
            ) : (
              <Empty description="No templates found" />
            )}
          </div>
        </Space>
      ) : (
        <Space direction="vertical" style={{ width: '100%' }} size="large">
          {/* Selected Template Info */}
          <Card size="small">
            <Space direction="vertical" style={{ width: '100%' }}>
              <Space>
                {categoryIcons[selectedTemplate.category]}
                <Title level={4} style={{ margin: 0 }}>
                  {selectedTemplate.name}
                </Title>
              </Space>
              <Text type="secondary">{selectedTemplate.description}</Text>
              <Tag color="blue">{selectedTemplate.category}</Tag>
            </Space>
          </Card>

          {/* Configuration Form */}
          <Form
            form={form}
            layout="vertical"
            initialValues={variableValues}
          >
            <Divider orientation="left">Rule Configuration</Divider>
            
            <Form.Item
              name="ruleName"
              label="Rule Name"
              rules={[
                { required: true, message: 'Please enter a rule name' },
                {
                  validator: (_, value) => {
                    if (existingRuleNames.includes(value)) {
                      return Promise.reject('A rule with this name already exists');
                    }
                    return Promise.resolve();
                  }
                }
              ]}
            >
              <Input placeholder="Enter unique rule name" />
            </Form.Item>

            {selectedTemplate.variables && selectedTemplate.variables.length > 0 && (
              <>
                <Divider orientation="left">Template Variables</Divider>
                {selectedTemplate.variables.map(variable => (
                  <Form.Item
                    key={variable.key}
                    name={variable.key}
                    label={variable.label}
                    rules={[
                      {
                        required: variable.required,
                        message: `Please provide ${variable.label}`
                      }
                    ]}
                    initialValue={variable.defaultValue}
                  >
                    {renderVariableInput(variable)}
                  </Form.Item>
                ))}
              </>
            )}
          </Form>
        </Space>
      )}
    </Modal>
  );
};

export default TemplateSelector;