import React, { useState, useEffect } from 'react';
import { Card, Button, Space, message, Row, Col, Statistic, Alert, Modal, Input, Spin, Tooltip } from 'antd';
import { SaveOutlined, ReloadOutlined, PlayCircleOutlined, HistoryOutlined, BulbOutlined } from '@ant-design/icons';
import SafeMonacoEditor from '../components/SafeMonacoEditor';
import genesysService from '../services/genesysService';

const { TextArea } = Input;

interface ActiveRules {
  version: string;
  rules: any;
  createdAt: string;
}

const RulesEditor: React.FC = () => {
  const [activeRules, setActiveRules] = useState<ActiveRules | null>(null);
  const [editedRules, setEditedRules] = useState<string>('{}');
  const [hasChanges, setHasChanges] = useState(false);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [validationErrors, setValidationErrors] = useState<string[]>([]);
  const [deployModalVisible, setDeployModalVisible] = useState(false);
  const [deployDescription, setDeployDescription] = useState('');
  const [testModalVisible, setTestModalVisible] = useState(false);
  const [testInput, setTestInput] = useState('{\n  "brand": "Admiral",\n  "intent": "sales",\n  "customerType": "regular"\n}');
  const [testResult, setTestResult] = useState<any>(null);

  useEffect(() => {
    loadActiveRules();
  }, []);

  const loadActiveRules = async () => {
    try {
      setLoading(true);
      const rules = await genesysService.getActiveRules();
      
      if (rules) {
        setActiveRules(rules);
        // Ensure rules.rules is a valid object
        const rulesData = rules.rules || {};
        setEditedRules(JSON.stringify(rulesData, null, 2));
      } else {
        // No active rules, start with default template
        const defaultRules = {
          engineOptions: {
            allowUndefinedFacts: true
          },
          logging: {
            enabled: true,
            logMatchedRules: true,
            logUnmatchedRules: false,
            logPerformanceMetrics: true
          },
          rules: [{
            name: 'defaultRule',
            description: 'Default routing rule',
            priority: 1,
            defaultDestination: 'Voice_Default_Queue',
            conditions: {
              all: [{
                fact: 'alwaysTrue',
                operator: 'equal',
                value: true
              }]
            },
            event: {
              type: 'route_determined',
              params: {
                destination: 'Voice_Default_Queue'
              }
            }
          }],
          dynamicFacts: [{
            name: 'alwaysTrue',
            calculator: 'return true;',
            options: { cache: true }
          }],
          customOperators: []
        };
        setEditedRules(JSON.stringify(defaultRules, null, 2));
      }
    } catch (error: any) {
      message.error(`Failed to load rules: ${error.message}`);
      console.error('Load error:', error);
      // Set a minimal valid JSON to prevent crashes
      setEditedRules('{}');
    } finally {
      setLoading(false);
    }
  };

  const handleEditorChange = (value: string | undefined) => {
    if (value !== undefined) {
      setEditedRules(value);
      setHasChanges(true);
      
      // Clear validation errors when user types
      if (validationErrors.length > 0) {
        setValidationErrors([]);
      }
    }
  };

  const validateRules = (): boolean => {
    const errors: string[] = [];
    
    try {
      const parsed = JSON.parse(editedRules);
      
      // Check required fields
      if (!parsed.rules || !Array.isArray(parsed.rules)) {
        errors.push('Missing or invalid field: rules (must be an array)');
      }
      
      if (parsed.rules && parsed.rules.length === 0) {
        errors.push('Rules array cannot be empty - at least one rule is required');
      }
      
      if (!parsed.rules || !Array.isArray(parsed.rules)) {
        errors.push('Missing or invalid field: rules (must be an array)');
      } else {
        // Validate each rule
        parsed.rules.forEach((rule: any, index: number) => {
          const ruleErrors: string[] = [];
          
          if (!rule.name) ruleErrors.push('name is required');
          if (typeof rule.priority !== 'number') ruleErrors.push('priority must be a number');
          if (!rule.conditions) ruleErrors.push('conditions are required');
          if (!rule.event) ruleErrors.push('event is required');
          if (rule.event && !rule.event.params?.destination) {
            ruleErrors.push('event.params.destination is required');
          }
          
          if (ruleErrors.length > 0) {
            errors.push(`Rule ${index + 1} (${rule.name || 'unnamed'}): ${ruleErrors.join(', ')}`);
          }
        });
      }
    } catch (e) {
      errors.push('Invalid JSON syntax');
    }
    
    setValidationErrors(errors);
    return errors.length === 0;
  };

  const handleSave = () => {
    if (!validateRules()) {
      message.error('Please fix validation errors before saving');
      return;
    }
    
    setDeployModalVisible(true);
  };

  const handleDeploy = async () => {
    if (!deployDescription.trim()) {
      message.error('Please provide a description for this deployment');
      return;
    }
    
    try {
      setSaving(true);
      const rules = JSON.parse(editedRules);
      
      await genesysService.deployRules(rules, deployDescription);
      
      message.success('Rules deployed successfully!');
      setHasChanges(false);
      setDeployDescription('');
      setDeployModalVisible(false);
      
      // Reload to get the new version
      await loadActiveRules();
    } catch (error: any) {
      message.error(`Deployment failed: ${error.message}`);
      console.error('Deploy error:', error);
    } finally {
      setSaving(false);
    }
  };

  const handleTest = () => {
    if (!validateRules()) return;
    setTestModalVisible(true);
    setTestResult(null);
  };

  const runTest = async () => {
    try {
      // Parse the test input
      let input;
      try {
        input = JSON.parse(testInput);
      } catch (e) {
        message.error('Invalid JSON in test input');
        return;
      }
      
      // Parse the rules
      let rules;
      try {
        rules = JSON.parse(editedRules);
      } catch (e) {
        message.error('Invalid JSON in rules configuration');
        return;
      }
      
      // Simple simulation
      console.log('Test Input:', input);
      console.log('Rules Configuration:', rules);
      
      // For UI testing, we'll do a simple simulation
      // In production, this would call the actual Lambda
      message.info('Test simulation - This is a UI preview only');
      
      // Check if we have an always-match rule for testing
      const alwaysMatchRule = rules.rules?.find(r => 
        r.conditions?.all?.length === 0 || 
        r.conditions?.any?.length === 0
      );
      
      if (alwaysMatchRule) {
        setTestResult({
          destination: alwaysMatchRule.event?.params?.destination || 'Unknown',
          matchedRules: [alwaysMatchRule.name],
          executionTime: Math.floor(Math.random() * 50) + 10,
          note: 'Matched empty condition rule'
        });
      } else {
        // For other rules, just show default destination
        // Real implementation would evaluate conditions
        setTestResult({
          destination: rules.rules?.[rules.rules.length - 1]?.defaultDestination || 'Default_Queue',
          matchedRules: [],
          executionTime: Math.floor(Math.random() * 50) + 10,
          note: 'UI test simulation only - deploy to test actual rule matching'
        });
      }
    } catch (error: any) {
      message.error(`Test failed: ${error.message}`);
      console.error('Test error:', error);
    }
  };

  const handleReset = () => {
    if (activeRules) {
      const rulesData = activeRules.rules || {};
      setEditedRules(JSON.stringify(rulesData, null, 2));
      setHasChanges(false);
      setValidationErrors([]);
      message.info('Reset to current active rules');
    } else {
      // If no active rules, reset to minimal valid JSON
      setEditedRules('{\n  "rules": []\n}');
      setHasChanges(false);
      setValidationErrors([]);
      message.info('Reset to empty rules');
    }
  };

  if (loading) {
    return (
      <div style={{ textAlign: 'center', padding: '50px' }}>
        <Spin size="large" tip="Loading rules..." />
      </div>
    );
  }

  return (
    <>
      {/* Header with stats */}
      <Row gutter={16} style={{ marginBottom: 16 }}>
        <Col span={6}>
          <Card>
            <Statistic 
              title="Active Version" 
              value={activeRules?.version || 'N/A'} 
              prefix="v"
            />
          </Card>
        </Col>
        <Col span={6}>
          <Card>
            <Statistic 
              title="Total Rules" 
              value={(() => {
                try {
                  const parsed = JSON.parse(editedRules);
                  return parsed.rules?.length || 0;
                } catch {
                  return 0;
                }
              })()} 
            />
          </Card>
        </Col>
        <Col span={6}>
          <Card>
            <Statistic 
              title="Last Updated" 
              value={activeRules?.createdAt ? new Date(activeRules.createdAt).toLocaleDateString() : 'Never'} 
            />
          </Card>
        </Col>
        <Col span={6}>
          <Card>
            <Statistic 
              title="Status" 
              value={hasChanges ? 'Modified' : 'Saved'} 
              valueStyle={{ color: hasChanges ? '#ff4d4f' : '#52c41a' }}
            />
          </Card>
        </Col>
      </Row>

      {/* Validation Errors */}
      {validationErrors.length > 0 && (
        <Alert
          message="Validation Errors"
          description={
            <ul>
              {validationErrors.map((error, index) => (
                <li key={index}>{error}</li>
              ))}
            </ul>
          }
          type="error"
          showIcon
          closable
          style={{ marginBottom: 16 }}
        />
      )}

      {/* Editor */}
      <Card
        title="Rules Configuration"
        extra={
          <Space>
            <Button 
              icon={<ReloadOutlined />} 
              onClick={handleReset}
              disabled={!hasChanges}
            >
              Reset
            </Button>
            <Button 
              icon={<PlayCircleOutlined />} 
              onClick={handleTest}
            >
              Test
            </Button>
            <Button 
              type="primary" 
              icon={<SaveOutlined />} 
              onClick={handleSave}
              disabled={!hasChanges}
              loading={saving}
            >
              Deploy Changes
            </Button>
          </Space>
        }
      >
        <SafeMonacoEditor
          value={editedRules}
          onChange={handleEditorChange}
          height="500px"
          language="json"
          theme="vs-dark"
        />
      </Card>

      {/* Deploy Modal */}
      <Modal
        title="Deploy Rules"
        open={deployModalVisible}
        onOk={handleDeploy}
        onCancel={() => setDeployModalVisible(false)}
        confirmLoading={saving}
      >
        <Space direction="vertical" style={{ width: '100%' }}>
          <div>
            Please provide a description for this deployment:
          </div>
          <TextArea
            rows={4}
            value={deployDescription}
            onChange={(e) => setDeployDescription(e.target.value)}
            placeholder="e.g., Added new routing rules for Admiral brand sales calls"
          />
        </Space>
      </Modal>

      {/* Test Modal */}
      <Modal
        title="Test Rules"
        open={testModalVisible}
        onOk={runTest}
        onCancel={() => setTestModalVisible(false)}
        width={700}
        okText="Run Test"
      >
        <Space direction="vertical" style={{ width: '100%' }} size="large">
          <div>
            <div style={{ marginBottom: 8 }}>
              <strong>Test Input Data</strong> (Enter the data to test against your rules):
            </div>
            <TextArea
              rows={6}
              value={testInput}
              onChange={(e) => setTestInput(e.target.value)}
              style={{ fontFamily: 'monospace' }}
              placeholder='Example:
{
  "brand": "Admiral",
  "intent": "sales",
  "customerType": "vip"
}'
            />
            <div style={{ marginTop: 8, fontSize: '12px', color: '#666' }}>
              💡 This should be test data (like {`{"brand": "Admiral"}`}), NOT rule conditions
            </div>
          </div>
          
          {testResult && (
            <Alert
              message="Test Result"
              description={
                <div>
                  <div><strong>Destination:</strong> {testResult.destination}</div>
                  <div><strong>Matched Rules:</strong> {testResult.matchedRules.join(', ') || 'None'}</div>
                  <div><strong>Execution Time:</strong> {testResult.executionTime}ms</div>
                  {testResult.note && (
                    <div style={{ marginTop: 8, fontStyle: 'italic', color: '#666' }}>
                      Note: {testResult.note}
                    </div>
                  )}
                </div>
              }
              type={testResult.matchedRules.length > 0 ? "success" : "info"}
              showIcon
            />
          )}
          
          <Alert
            message="Test Limitations"
            description="This is a UI simulation only. The actual rule engine runs in Lambda. Deploy your rules and test with the Data Action for accurate results."
            type="warning"
            showIcon
          />
        </Space>
      </Modal>
    </>
  );
};

export default RulesEditor;